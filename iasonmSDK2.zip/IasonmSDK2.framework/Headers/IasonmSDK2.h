//
//  IasonmSDK2.h
//  IasonmSDK2
//
//  Created by Iason Michailidis on 30/08/2018.
//  Copyright © 2018 Iason Michailidis. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IasonmSDK2.
FOUNDATION_EXPORT double IasonmSDK2VersionNumber;

//! Project version string for IasonmSDK2.
FOUNDATION_EXPORT const unsigned char IasonmSDK2VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IasonmSDK2/PublicHeader.h>


